<?php
include '../../mainfile.php';
require_once XOOPS_ROOT_PATH.'/include/notification_update.php';
?>