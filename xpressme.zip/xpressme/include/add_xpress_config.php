<?php
require_once dirname( __FILE__ ).'/xpress_debug_log.php' ;
require_once dirname(dirname( __FILE__ )).'/class/config_from_xoops.class.php' ;
$xoops_config = new ConfigFromXoops;
require_once dirname( __FILE__ ).'/set_cash_cookie_path.php' ;
?>