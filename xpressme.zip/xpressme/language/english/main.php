<?php
if( ! defined( 'XP2_MAIN_LANG_INCLUDED' ) ) {
	define( 'XP2_MAIN_LANG_INCLUDED' , 1 ) ;
	
}
?>